package part1;

public record Wine(
                float[] attributes,
                int type) {
}